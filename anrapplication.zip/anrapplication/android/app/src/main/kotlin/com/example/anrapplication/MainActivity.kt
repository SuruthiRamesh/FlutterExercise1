package com.example.anrapplication

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
